// MODIFIED!!! Please do not replace with the normal dgframe.js.

function EventEmitter() {
  this.listeners = {};
}

EventEmitter.prototype = {
  emit: function(name) {
    var args = [];
    var count = 1;
    var length = arguments.length;

    for(; count < length; count++) {
      args.push(arguments[count]);
    }

    (this.listeners[name] || []).forEach(function(f) {
      f.apply(this, args);
    }, this);
  },
  on: function(name, listener) {
    if(!this.listeners[name])
      this.listeners[name] = [];
    this.listeners[name].push(listener);
    return listener;
  },
  remove: function(name, listener) {
    if(!this.listeners[name] || this.listeners[name].indexOf(listener) === -1)
      return null;
    return this.listeners[name].splice(this.listeners[name].indexOf(listener), 1);
  }
};

var dgParams = new EventEmitter();
var dgIframeId;

// test if a parameter value is dglux table
function dgIsParamTable(value) {
  return (val != null && typeof(val)=='object' && val.hasOwnProperty('cols') && val.hasOwnProperty('rows'));
}

function dgChangeParam(key, value) {
  var map = {};
  map[key] = value;

  window.parent.postMessage({
    dgIframe: dgIframeId,
    changes: map
  },'*');
}

function dgSendMessage(message, group) {
  window.parent.postMessage({
    dgIFrame: dgIframeId,
    dgIframeMessageGroup: group,
    dgIframeMessage: JSON.encode(message)
  });
}

// interface to the dglux5 application
function onDGFrameMessage(e) {
  var data = e.data;
  if(typeof(data)=='object') {
    if(data.hasOwnProperty('dgIframeInit')) {
      dgIframeId = data['dgIframeInit'];
      if(window.parent != null) {
        // the first post back shouldn't contain any data change
        window.parent.postMessage({
          dgIframe: dgIframeId
        },'*');
      }
    } else if(data.hasOwnProperty('dgIframeUpdate')) {
      var updates = data['updates'];
      if(typeof(updates) == 'object') {
        for (key in updates) {
          if (updates.hasOwnProperty(key)){
            dgParams.emit(key, updates[key]);
          }
        }
      }
    }
  }
}

window.addEventListener('message', onDGFrameMessage);
